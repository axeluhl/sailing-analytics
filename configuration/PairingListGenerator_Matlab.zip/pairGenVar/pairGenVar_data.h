/*
 * File: pairGenVar_data.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

#ifndef PAIRGENVAR_DATA_H
#define PAIRGENVAR_DATA_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "pairGenVar_types.h"

/* Variable Declarations */
extern unsigned int state[625];

#endif

/*
 * File trailer for pairGenVar_data.h
 *
 * [EOF]
 */
