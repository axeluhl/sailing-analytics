/* 
 * File: _coder_pairGenVar_info.h 
 *  
 * MATLAB Coder version            : 3.1 
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52 
 */

#ifndef _CODER_PAIRGENVAR_INFO_H
#define _CODER_PAIRGENVAR_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#endif
/* 
 * File trailer for _coder_pairGenVar_info.h 
 *  
 * [EOF] 
 */
