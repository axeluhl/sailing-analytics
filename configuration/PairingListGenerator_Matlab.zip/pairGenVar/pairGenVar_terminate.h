/*
 * File: pairGenVar_terminate.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

#ifndef PAIRGENVAR_TERMINATE_H
#define PAIRGENVAR_TERMINATE_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "pairGenVar_types.h"

/* Function Declarations */
extern void pairGenVar_terminate(void);

#endif

/*
 * File trailer for pairGenVar_terminate.h
 *
 * [EOF]
 */
