/*
 * File: pairGenVar.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "pairGenVar.h"
#include "pairGenVar_emxutil.h"
#include "sum.h"
#include "all.h"
#include "match.h"
#include "rand.h"
#include "characterize.h"
#include "shuffle.h"

/* Function Declarations */
static double rt_roundd_snf(double u);

/* Function Definitions */

/*
 * Arguments    : double u
 * Return Type  : double
 */
static double rt_roundd_snf(double u)
{
  double y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/*
 * Iterative determination of best pairing system for NRace races per flight
 * Pre-defining frame parameters of optimization problem for NRace races per
 * flight
 * Sanity checks
 * Arguments    : double flights
 *                double boats
 *                double teams
 *                double nIter
 *                emxArray_real_T *PBest
 *                emxArray_real_T *ABest
 *                emxArray_real_T *histBest
 *                double devBest_data[]
 *                int devBest_size[2]
 * Return Type  : void
 */
void pairGenVar(double flights, double boats, double teams, double nIter,
                emxArray_real_T *PBest, emxArray_real_T *ABest, emxArray_real_T *
                histBest, double devBest_data[], int devBest_size[2])
{
  double mtmp;
  int i0;
  double NRace;
  int loop_ub;
  int r;
  emxArray_real_T *A;
  emxArray_real_T *P;
  emxArray_real_T *x;
  emxArray_real_T *pair_stats;
  emxArray_real_T *pair_max;
  emxArray_real_T *unusedU0;
  emxArray_int32_T *r0;
  emxArray_real_T *r1;
  emxArray_boolean_T *r2;
  emxArray_real_T *b_pair_stats;
  emxArray_boolean_T *b_x;
  emxArray_real_T *c_pair_stats;
  emxArray_boolean_T *c_x;
  emxArray_real_T *d_pair_stats;
  emxArray_boolean_T *d_x;
  emxArray_real_T *e_pair_stats;
  emxArray_boolean_T *e_x;
  emxArray_real_T *f_x;
  emxArray_real_T *b_A;
  emxArray_real_T *c_A;
  int nr_flight;
  emxArray_real_T *b_PBest;
  int d;
  double currentDev;
  int i;
  int a;
  double pair_min;
  int aux;
  boolean_T exitg4;
  int m;
  boolean_T exitg1;
  int ix;
  int ixstart;
  int j;
  int n;
  boolean_T exitg6;
  boolean_T exitg3;
  boolean_T exitg5;
  boolean_T exitg2;
  if (boats == 0.0) {
    mtmp = teams;
  } else if (boats == floor(boats)) {
    mtmp = teams - floor(teams / boats) * boats;
  } else {
    mtmp = teams / boats;
    if (fabs(mtmp - rt_roundd_snf(mtmp)) <= 2.2204460492503131E-16 * fabs(mtmp))
    {
      mtmp = 0.0;
    } else {
      mtmp = (mtmp - floor(mtmp)) * boats;
    }
  }

  if (mtmp != 0.0) {
    i0 = PBest->size[0] * PBest->size[1];
    PBest->size[0] = 0;
    PBest->size[1] = 0;
    emxEnsureCapacity((emxArray__common *)PBest, i0, (int)sizeof(double));
    i0 = ABest->size[0] * ABest->size[1];
    ABest->size[0] = 0;
    ABest->size[1] = 0;
    emxEnsureCapacity((emxArray__common *)ABest, i0, (int)sizeof(double));
    i0 = histBest->size[0] * histBest->size[1];
    histBest->size[0] = 0;
    histBest->size[1] = 0;
    emxEnsureCapacity((emxArray__common *)histBest, i0, (int)sizeof(double));
    devBest_size[0] = 0;
    devBest_size[1] = 0;
  } else {
    /* Determine number of races */
    NRace = teams / boats;

    /* Initialize void 'best'-parameters */
    i0 = ABest->size[0] * ABest->size[1];
    ABest->size[0] = (int)teams;
    ABest->size[1] = (int)teams;
    emxEnsureCapacity((emxArray__common *)ABest, i0, (int)sizeof(double));
    loop_ub = (int)teams * (int)teams;
    for (i0 = 0; i0 < loop_ub; i0++) {
      ABest->data[i0] = 0.0;
    }

    mtmp = flights * teams / boats;
    i0 = PBest->size[0] * PBest->size[1];
    PBest->size[0] = (int)mtmp;
    PBest->size[1] = (int)boats;
    emxEnsureCapacity((emxArray__common *)PBest, i0, (int)sizeof(double));
    loop_ub = (int)mtmp * (int)boats;
    for (i0 = 0; i0 < loop_ub; i0++) {
      PBest->data[i0] = 0.0;
    }

    i0 = histBest->size[0] * histBest->size[1];
    histBest->size[0] = 0;
    histBest->size[1] = 0;
    emxEnsureCapacity((emxArray__common *)histBest, i0, (int)sizeof(double));
    devBest_size[0] = 1;
    devBest_size[1] = 1;
    devBest_data[0] = rtInf;

    /* Start with initial stdDev that is higher than any naturally occuring value */
    /* Specifiy number of iterations */
    r = 0;
    emxInit_real_T(&A, 2);
    emxInit_real_T(&P, 2);
    emxInit_real_T(&x, 2);
    emxInit_real_T1(&pair_stats, 3);
    emxInit_real_T2(&pair_max, 1);
    emxInit_real_T(&unusedU0, 2);
    emxInit_int32_T(&r0, 1);
    emxInit_real_T(&r1, 2);
    emxInit_boolean_T(&r2, 2);
    emxInit_real_T(&b_pair_stats, 2);
    emxInit_boolean_T(&b_x, 2);
    emxInit_real_T(&c_pair_stats, 2);
    emxInit_boolean_T(&c_x, 2);
    emxInit_real_T(&d_pair_stats, 2);
    emxInit_boolean_T(&d_x, 2);
    emxInit_real_T(&e_pair_stats, 2);
    emxInit_boolean_T(&e_x, 2);
    emxInit_real_T(&f_x, 2);
    emxInit_real_T(&b_A, 2);
    emxInit_real_T(&c_A, 2);
    while (r <= (int)nIter - 1) {
      i0 = A->size[0] * A->size[1];
      A->size[0] = (int)teams;
      A->size[1] = (int)teams;
      emxEnsureCapacity((emxArray__common *)A, i0, (int)sizeof(double));
      loop_ub = (int)teams * (int)teams;
      for (i0 = 0; i0 < loop_ub; i0++) {
        A->data[i0] = 0.0;
      }

      mtmp = flights * teams / boats;
      i0 = P->size[0] * P->size[1];
      P->size[0] = (int)mtmp;
      P->size[1] = (int)boats;
      emxEnsureCapacity((emxArray__common *)P, i0, (int)sizeof(double));
      loop_ub = (int)mtmp * (int)boats;
      for (i0 = 0; i0 < loop_ub; i0++) {
        P->data[i0] = 0.0;
      }

      for (nr_flight = 0; nr_flight < (int)flights; nr_flight++) {
        /* allocating three "match-pairing" matrices */
        i0 = x->size[0] * x->size[1];
        x->size[0] = (int)NRace;
        x->size[1] = (int)boats;
        emxEnsureCapacity((emxArray__common *)x, i0, (int)sizeof(double));
        loop_ub = (int)NRace * (int)boats;
        for (i0 = 0; i0 < loop_ub; i0++) {
          x->data[i0] = 0.0;
        }

        i0 = pair_stats->size[0] * pair_stats->size[1] * pair_stats->size[2];
        pair_stats->size[0] = (int)(NRace - 1.0);
        pair_stats->size[1] = (int)(boats - 1.0);
        pair_stats->size[2] = (int)teams;
        emxEnsureCapacity((emxArray__common *)pair_stats, i0, (int)sizeof(double));
        loop_ub = (int)(NRace - 1.0) * (int)(boats - 1.0) * (int)teams;
        for (i0 = 0; i0 < loop_ub; i0++) {
          pair_stats->data[i0] = 0.0;
        }

        i0 = pair_max->size[0];
        pair_max->size[0] = (int)(NRace - 1.0);
        emxEnsureCapacity((emxArray__common *)pair_max, i0, (int)sizeof(double));
        loop_ub = (int)(NRace - 1.0);
        for (i0 = 0; i0 < loop_ub; i0++) {
          pair_max->data[i0] = 0.0;
        }

        /* filling in pairings for RACE 1 */
        /* taking a random team as initial competitor */
        mtmp = b_rand();
        x->data[0] = 1.0 + floor(mtmp * teams);

        /* finding every subsequent competitor with as little races priorly sailed */
        /* against the already chosen competitors as possible */
        for (i = 0; i < (int)(boats - 1.0); i++) {
          pair_min = (flights + 1.0) * boats;

          /* make sure pair_min is larger than pairstats for 1st iteration */
          pair_max->data[0] = flights + 1.0;
          loop_ub = pair_stats->size[2];
          i0 = r0->size[0];
          r0->size[0] = loop_ub;
          emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(int));
          for (i0 = 0; i0 < loop_ub; i0++) {
            r0->data[i0] = i0;
          }

          loop_ub = A->size[1];
          ix = (int)x->data[x->size[0] * i];
          i0 = c_A->size[0] * c_A->size[1];
          c_A->size[0] = 1;
          c_A->size[1] = loop_ub;
          emxEnsureCapacity((emxArray__common *)c_A, i0, (int)sizeof(double));
          for (i0 = 0; i0 < loop_ub; i0++) {
            c_A->data[c_A->size[0] * i0] = A->data[(ix + A->size[0] * i0) - 1];
          }

          ix = r0->size[0];
          for (i0 = 0; i0 < ix; i0++) {
            pair_stats->data[pair_stats->size[0] * i + pair_stats->size[0] *
              pair_stats->size[1] * r0->data[i0]] = c_A->data[i0];
          }

          for (j = 0; j < (int)teams; j++) {
            loop_ub = pair_stats->size[1];
            i0 = c_pair_stats->size[0] * c_pair_stats->size[1];
            c_pair_stats->size[0] = 1;
            c_pair_stats->size[1] = loop_ub;
            emxEnsureCapacity((emxArray__common *)c_pair_stats, i0, (int)sizeof
                              (double));
            for (i0 = 0; i0 < loop_ub; i0++) {
              c_pair_stats->data[c_pair_stats->size[0] * i0] = pair_stats->
                data[pair_stats->size[0] * i0 + pair_stats->size[0] *
                pair_stats->size[1] * j];
            }

            if (sum(c_pair_stats) <= pair_min) {
              loop_ub = x->size[1];
              i0 = b_x->size[0] * b_x->size[1];
              b_x->size[0] = 1;
              b_x->size[1] = loop_ub;
              emxEnsureCapacity((emxArray__common *)b_x, i0, (int)sizeof
                                (boolean_T));
              for (i0 = 0; i0 < loop_ub; i0++) {
                b_x->data[b_x->size[0] * i0] = (x->data[x->size[0] * i0] != 1.0
                  + (double)j);
              }

              if (all(b_x)) {
                loop_ub = pair_stats->size[1];
                i0 = unusedU0->size[0] * unusedU0->size[1];
                unusedU0->size[0] = 1;
                unusedU0->size[1] = loop_ub;
                emxEnsureCapacity((emxArray__common *)unusedU0, i0, (int)sizeof
                                  (double));
                for (i0 = 0; i0 < loop_ub; i0++) {
                  unusedU0->data[unusedU0->size[0] * i0] = pair_stats->
                    data[pair_stats->size[0] * i0 + pair_stats->size[0] *
                    pair_stats->size[1] * j];
                }

                ixstart = 1;
                n = pair_stats->size[1];
                loop_ub = pair_stats->size[1];
                i0 = r1->size[0] * r1->size[1];
                r1->size[0] = 1;
                r1->size[1] = loop_ub;
                emxEnsureCapacity((emxArray__common *)r1, i0, (int)sizeof(double));
                for (i0 = 0; i0 < loop_ub; i0++) {
                  r1->data[r1->size[0] * i0] = pair_stats->data[pair_stats->
                    size[0] * i0 + pair_stats->size[0] * pair_stats->size[1] * j];
                }

                mtmp = r1->data[0];
                i0 = pair_stats->size[1];
                if (i0 > 1) {
                  if (rtIsNaN(mtmp)) {
                    ix = 2;
                    exitg6 = false;
                    while ((!exitg6) && (ix <= n)) {
                      ixstart = ix;
                      if (!rtIsNaN(unusedU0->data[ix - 1])) {
                        mtmp = unusedU0->data[ix - 1];
                        exitg6 = true;
                      } else {
                        ix++;
                      }
                    }
                  }

                  i0 = pair_stats->size[1];
                  if (ixstart < i0) {
                    while (ixstart + 1 <= n) {
                      if (unusedU0->data[ixstart] > mtmp) {
                        mtmp = unusedU0->data[ixstart];
                      }

                      ixstart++;
                    }
                  }
                }

                if (mtmp <= pair_max->data[0]) {
                  x->data[x->size[0] * ((int)((1.0 + (double)i) + 1.0) - 1)] =
                    1.0 + (double)j;
                  loop_ub = pair_stats->size[1];
                  i0 = b_pair_stats->size[0] * b_pair_stats->size[1];
                  b_pair_stats->size[0] = 1;
                  b_pair_stats->size[1] = loop_ub;
                  emxEnsureCapacity((emxArray__common *)b_pair_stats, i0, (int)
                                    sizeof(double));
                  for (i0 = 0; i0 < loop_ub; i0++) {
                    b_pair_stats->data[b_pair_stats->size[0] * i0] =
                      pair_stats->data[pair_stats->size[0] * i0 +
                      pair_stats->size[0] * pair_stats->size[1] * j];
                  }

                  pair_min = sum(b_pair_stats);
                  loop_ub = pair_stats->size[1];
                  i0 = unusedU0->size[0] * unusedU0->size[1];
                  unusedU0->size[0] = 1;
                  unusedU0->size[1] = loop_ub;
                  emxEnsureCapacity((emxArray__common *)unusedU0, i0, (int)
                                    sizeof(double));
                  for (i0 = 0; i0 < loop_ub; i0++) {
                    unusedU0->data[unusedU0->size[0] * i0] = pair_stats->
                      data[pair_stats->size[0] * i0 + pair_stats->size[0] *
                      pair_stats->size[1] * j];
                  }

                  ixstart = 1;
                  n = pair_stats->size[1];
                  loop_ub = pair_stats->size[1];
                  i0 = r1->size[0] * r1->size[1];
                  r1->size[0] = 1;
                  r1->size[1] = loop_ub;
                  emxEnsureCapacity((emxArray__common *)r1, i0, (int)sizeof
                                    (double));
                  for (i0 = 0; i0 < loop_ub; i0++) {
                    r1->data[r1->size[0] * i0] = pair_stats->data
                      [pair_stats->size[0] * i0 + pair_stats->size[0] *
                      pair_stats->size[1] * j];
                  }

                  mtmp = r1->data[0];
                  i0 = pair_stats->size[1];
                  if (i0 > 1) {
                    if (rtIsNaN(mtmp)) {
                      ix = 2;
                      exitg5 = false;
                      while ((!exitg5) && (ix <= n)) {
                        ixstart = ix;
                        if (!rtIsNaN(unusedU0->data[ix - 1])) {
                          mtmp = unusedU0->data[ix - 1];
                          exitg5 = true;
                        } else {
                          ix++;
                        }
                      }
                    }

                    i0 = pair_stats->size[1];
                    if (ixstart < i0) {
                      while (ixstart + 1 <= n) {
                        if (unusedU0->data[ixstart] > mtmp) {
                          mtmp = unusedU0->data[ixstart];
                        }

                        ixstart++;
                      }
                    }
                  }

                  pair_max->data[0] = mtmp;
                }
              }
            }
          }
        }

        for (a = 1; a - 1 < (int)((NRace - 1.0) + -1.0); a++) {
          /* filling in pairings for RACES 2-(NRace-1) */
          /* defining the team with the lowest number (that has not yet been */
          /* allocated to match 1) as the initial competitor of match 2 */
          aux = 0;
          exitg4 = false;
          while ((!exitg4) && (aux <= (int)teams - 1)) {
            loop_ub = (int)((2.0 + (double)(a - 1)) - 1.0);
            ix = x->size[1];
            i0 = c_x->size[0] * c_x->size[1];
            c_x->size[0] = (int)((2.0 + (double)(a - 1)) - 1.0);
            c_x->size[1] = ix;
            emxEnsureCapacity((emxArray__common *)c_x, i0, (int)sizeof(boolean_T));
            for (i0 = 0; i0 < ix; i0++) {
              for (ixstart = 0; ixstart < loop_ub; ixstart++) {
                c_x->data[ixstart + c_x->size[0] * i0] = (x->data[ixstart +
                  x->size[0] * i0] != 1.0 + (double)aux);
              }
            }

            b_all(c_x, r2);
            if (c_all(r2)) {
              x->data[a] = 1.0 + (double)aux;
              exitg4 = true;
            } else {
              aux++;
            }
          }

          /* finding every subsequent competitor with as little races priorly sailed */
          /* against the already chosen competitors as possible */
          for (i = 0; i < (int)(boats - 1.0); i++) {
            pair_min = (flights + 1.0) * boats;
            pair_max->data[a] = flights + 1.0;
            loop_ub = pair_stats->size[2];
            i0 = r0->size[0];
            r0->size[0] = loop_ub;
            emxEnsureCapacity((emxArray__common *)r0, i0, (int)sizeof(int));
            for (i0 = 0; i0 < loop_ub; i0++) {
              r0->data[i0] = i0;
            }

            loop_ub = A->size[1];
            ix = (int)x->data[a + x->size[0] * i];
            i0 = b_A->size[0] * b_A->size[1];
            b_A->size[0] = 1;
            b_A->size[1] = loop_ub;
            emxEnsureCapacity((emxArray__common *)b_A, i0, (int)sizeof(double));
            for (i0 = 0; i0 < loop_ub; i0++) {
              b_A->data[b_A->size[0] * i0] = A->data[(ix + A->size[0] * i0) - 1];
            }

            ix = r0->size[0];
            for (i0 = 0; i0 < ix; i0++) {
              pair_stats->data[(a + pair_stats->size[0] * i) + pair_stats->size
                [0] * pair_stats->size[1] * r0->data[i0]] = b_A->data[i0];
            }

            for (j = 0; j < (int)teams; j++) {
              loop_ub = pair_stats->size[1];
              i0 = e_pair_stats->size[0] * e_pair_stats->size[1];
              e_pair_stats->size[0] = 1;
              e_pair_stats->size[1] = loop_ub;
              emxEnsureCapacity((emxArray__common *)e_pair_stats, i0, (int)
                                sizeof(double));
              for (i0 = 0; i0 < loop_ub; i0++) {
                e_pair_stats->data[e_pair_stats->size[0] * i0] =
                  pair_stats->data[(a + pair_stats->size[0] * i0) +
                  pair_stats->size[0] * pair_stats->size[1] * j];
              }

              if (sum(e_pair_stats) <= pair_min) {
                loop_ub = (int)(2.0 + (double)(a - 1));
                ix = x->size[1];
                i0 = d_x->size[0] * d_x->size[1];
                d_x->size[0] = (int)(2.0 + (double)(a - 1));
                d_x->size[1] = ix;
                emxEnsureCapacity((emxArray__common *)d_x, i0, (int)sizeof
                                  (boolean_T));
                for (i0 = 0; i0 < ix; i0++) {
                  for (ixstart = 0; ixstart < loop_ub; ixstart++) {
                    d_x->data[ixstart + d_x->size[0] * i0] = (x->data[ixstart +
                      x->size[0] * i0] != 1.0 + (double)j);
                  }
                }

                d_all(d_x, r2);
                if (all(r2)) {
                  loop_ub = pair_stats->size[1];
                  i0 = unusedU0->size[0] * unusedU0->size[1];
                  unusedU0->size[0] = 1;
                  unusedU0->size[1] = loop_ub;
                  emxEnsureCapacity((emxArray__common *)unusedU0, i0, (int)
                                    sizeof(double));
                  for (i0 = 0; i0 < loop_ub; i0++) {
                    unusedU0->data[unusedU0->size[0] * i0] = pair_stats->data[(a
                      + pair_stats->size[0] * i0) + pair_stats->size[0] *
                      pair_stats->size[1] * j];
                  }

                  ixstart = 1;
                  n = pair_stats->size[1];
                  loop_ub = pair_stats->size[1];
                  i0 = r1->size[0] * r1->size[1];
                  r1->size[0] = 1;
                  r1->size[1] = loop_ub;
                  emxEnsureCapacity((emxArray__common *)r1, i0, (int)sizeof
                                    (double));
                  for (i0 = 0; i0 < loop_ub; i0++) {
                    r1->data[r1->size[0] * i0] = pair_stats->data[(a +
                      pair_stats->size[0] * i0) + pair_stats->size[0] *
                      pair_stats->size[1] * j];
                  }

                  mtmp = r1->data[0];
                  i0 = pair_stats->size[1];
                  if (i0 > 1) {
                    if (rtIsNaN(mtmp)) {
                      ix = 2;
                      exitg3 = false;
                      while ((!exitg3) && (ix <= n)) {
                        ixstart = ix;
                        if (!rtIsNaN(unusedU0->data[ix - 1])) {
                          mtmp = unusedU0->data[ix - 1];
                          exitg3 = true;
                        } else {
                          ix++;
                        }
                      }
                    }

                    i0 = pair_stats->size[1];
                    if (ixstart < i0) {
                      while (ixstart + 1 <= n) {
                        if (unusedU0->data[ixstart] > mtmp) {
                          mtmp = unusedU0->data[ixstart];
                        }

                        ixstart++;
                      }
                    }
                  }

                  if (mtmp <= pair_max->data[a]) {
                    x->data[a + x->size[0] * ((int)((1.0 + (double)i) + 1.0) - 1)]
                      = 1.0 + (double)j;
                    loop_ub = pair_stats->size[1];
                    i0 = d_pair_stats->size[0] * d_pair_stats->size[1];
                    d_pair_stats->size[0] = 1;
                    d_pair_stats->size[1] = loop_ub;
                    emxEnsureCapacity((emxArray__common *)d_pair_stats, i0, (int)
                                      sizeof(double));
                    for (i0 = 0; i0 < loop_ub; i0++) {
                      d_pair_stats->data[d_pair_stats->size[0] * i0] =
                        pair_stats->data[(a + pair_stats->size[0] * i0) +
                        pair_stats->size[0] * pair_stats->size[1] * j];
                    }

                    pair_min = sum(d_pair_stats);
                    loop_ub = pair_stats->size[1];
                    i0 = unusedU0->size[0] * unusedU0->size[1];
                    unusedU0->size[0] = 1;
                    unusedU0->size[1] = loop_ub;
                    emxEnsureCapacity((emxArray__common *)unusedU0, i0, (int)
                                      sizeof(double));
                    for (i0 = 0; i0 < loop_ub; i0++) {
                      unusedU0->data[unusedU0->size[0] * i0] = pair_stats->data
                        [(a + pair_stats->size[0] * i0) + pair_stats->size[0] *
                        pair_stats->size[1] * j];
                    }

                    ixstart = 1;
                    n = pair_stats->size[1];
                    loop_ub = pair_stats->size[1];
                    i0 = r1->size[0] * r1->size[1];
                    r1->size[0] = 1;
                    r1->size[1] = loop_ub;
                    emxEnsureCapacity((emxArray__common *)r1, i0, (int)sizeof
                                      (double));
                    for (i0 = 0; i0 < loop_ub; i0++) {
                      r1->data[r1->size[0] * i0] = pair_stats->data[(a +
                        pair_stats->size[0] * i0) + pair_stats->size[0] *
                        pair_stats->size[1] * j];
                    }

                    mtmp = r1->data[0];
                    i0 = pair_stats->size[1];
                    if (i0 > 1) {
                      if (rtIsNaN(mtmp)) {
                        ix = 2;
                        exitg2 = false;
                        while ((!exitg2) && (ix <= n)) {
                          ixstart = ix;
                          if (!rtIsNaN(unusedU0->data[ix - 1])) {
                            mtmp = unusedU0->data[ix - 1];
                            exitg2 = true;
                          } else {
                            ix++;
                          }
                        }
                      }

                      i0 = pair_stats->size[1];
                      if (ixstart < i0) {
                        while (ixstart + 1 <= n) {
                          if (unusedU0->data[ixstart] > mtmp) {
                            mtmp = unusedU0->data[ixstart];
                          }

                          ixstart++;
                        }
                      }
                    }

                    pair_max->data[a] = mtmp;
                  }
                }
              }
            }
          }
        }

        /* filling in pairings for last RACE  */
        /* (teams competing in last race are all those, who do not compete in */
        /* any of the previous races */
        for (i = 0; i < (int)boats; i++) {
          aux = 0;
          exitg1 = false;
          while ((!exitg1) && (aux <= (int)teams - 1)) {
            i0 = e_x->size[0] * e_x->size[1];
            e_x->size[0] = x->size[0];
            e_x->size[1] = x->size[1];
            emxEnsureCapacity((emxArray__common *)e_x, i0, (int)sizeof(boolean_T));
            loop_ub = x->size[0] * x->size[1];
            for (i0 = 0; i0 < loop_ub; i0++) {
              e_x->data[i0] = (x->data[i0] != 1.0 + (double)aux);
            }

            d_all(e_x, r2);
            if (all(r2)) {
              x->data[((int)NRace + x->size[0] * i) - 1] = 1.0 + (double)aux;
              exitg1 = true;
            } else {
              aux++;
            }
          }
        }

        /* Updating Matrices A and P */
        for (m = 0; m < (int)NRace; m++) {
          loop_ub = x->size[1];
          i0 = f_x->size[0] * f_x->size[1];
          f_x->size[0] = 1;
          f_x->size[1] = loop_ub;
          emxEnsureCapacity((emxArray__common *)f_x, i0, (int)sizeof(double));
          for (i0 = 0; i0 < loop_ub; i0++) {
            f_x->data[f_x->size[0] * i0] = x->data[m + x->size[0] * i0];
          }

          match(A, f_x);
        }

        for (m = 0; m < (int)NRace; m++) {
          i0 = (int)(((1.0 + (double)nr_flight) - 1.0) * NRace + (1.0 + (double)
                      m)) - 1;
          loop_ub = x->size[1] - 1;
          for (ixstart = 0; ixstart <= loop_ub; ixstart++) {
            P->data[i0 + P->size[0] * ixstart] = x->data[m + x->size[0] *
              ixstart];
          }
        }
      }

      /* All main diagonal elements in A are converted to NaN to facilitate statistical */
      /* analysis */
      for (d = 0; d < (int)teams; d++) {
        A->data[d + A->size[0] * d] = rtNaN;
      }

      characterize(A, &currentDev, unusedU0);
      if (currentDev < devBest_data[0]) {
        i0 = ABest->size[0] * ABest->size[1];
        ABest->size[0] = A->size[0];
        ABest->size[1] = A->size[1];
        emxEnsureCapacity((emxArray__common *)ABest, i0, (int)sizeof(double));
        loop_ub = A->size[0] * A->size[1];
        for (i0 = 0; i0 < loop_ub; i0++) {
          ABest->data[i0] = A->data[i0];
        }

        i0 = PBest->size[0] * PBest->size[1];
        PBest->size[0] = P->size[0];
        PBest->size[1] = P->size[1];
        emxEnsureCapacity((emxArray__common *)PBest, i0, (int)sizeof(double));
        loop_ub = P->size[0] * P->size[1];
        for (i0 = 0; i0 < loop_ub; i0++) {
          PBest->data[i0] = P->data[i0];
        }

        characterize(A, &mtmp, unusedU0);
        devBest_size[0] = 1;
        devBest_size[1] = 1;
        devBest_data[0] = mtmp;
        i0 = histBest->size[0] * histBest->size[1];
        histBest->size[0] = 1;
        histBest->size[1] = unusedU0->size[1];
        emxEnsureCapacity((emxArray__common *)histBest, i0, (int)sizeof(double));
        loop_ub = unusedU0->size[0] * unusedU0->size[1];
        for (i0 = 0; i0 < loop_ub; i0++) {
          histBest->data[i0] = unusedU0->data[i0];
        }
      }

      r++;
    }

    emxFree_real_T(&c_A);
    emxFree_real_T(&b_A);
    emxFree_real_T(&f_x);
    emxFree_boolean_T(&e_x);
    emxFree_real_T(&e_pair_stats);
    emxFree_boolean_T(&d_x);
    emxFree_real_T(&d_pair_stats);
    emxFree_boolean_T(&c_x);
    emxFree_real_T(&c_pair_stats);
    emxFree_boolean_T(&b_x);
    emxFree_real_T(&b_pair_stats);
    emxFree_boolean_T(&r2);
    emxFree_real_T(&r1);
    emxFree_int32_T(&r0);
    emxFree_real_T(&unusedU0);
    emxFree_real_T(&pair_max);
    emxFree_real_T(&pair_stats);
    emxFree_real_T(&x);
    emxFree_real_T(&P);
    emxFree_real_T(&A);
    emxInit_real_T(&b_PBest, 2);
    i0 = b_PBest->size[0] * b_PBest->size[1];
    b_PBest->size[0] = PBest->size[0];
    b_PBest->size[1] = PBest->size[1];
    emxEnsureCapacity((emxArray__common *)b_PBest, i0, (int)sizeof(double));
    loop_ub = PBest->size[0] * PBest->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_PBest->data[i0] = PBest->data[i0];
    }

    shuffle(b_PBest, PBest);
    emxFree_real_T(&b_PBest);
  }
}

/*
 * File trailer for pairGenVar.c
 *
 * [EOF]
 */
