/*
 * File: all.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "pairGenVar.h"
#include "all.h"
#include "pairGenVar_emxutil.h"

/* Function Definitions */

/*
 * Arguments    : const emxArray_boolean_T *x
 * Return Type  : boolean_T
 */
boolean_T all(const emxArray_boolean_T *x)
{
  boolean_T y;
  int ix;
  boolean_T exitg1;
  y = true;
  ix = 1;
  exitg1 = false;
  while ((!exitg1) && (ix <= x->size[1])) {
    if (!x->data[ix - 1]) {
      y = false;
      exitg1 = true;
    } else {
      ix++;
    }
  }

  return y;
}

/*
 * Arguments    : const emxArray_boolean_T *x
 *                emxArray_boolean_T *y
 * Return Type  : void
 */
void b_all(const emxArray_boolean_T *x, emxArray_boolean_T *y)
{
  unsigned int outsize[2];
  int i2;
  int iy;
  int i;
  int i1;
  boolean_T exitg1;
  for (i2 = 0; i2 < 2; i2++) {
    outsize[i2] = (unsigned int)x->size[i2];
  }

  i2 = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = (int)outsize[1];
  emxEnsureCapacity((emxArray__common *)y, i2, (int)sizeof(boolean_T));
  iy = (int)outsize[1];
  for (i2 = 0; i2 < iy; i2++) {
    y->data[i2] = true;
  }

  i2 = 0;
  iy = -1;
  for (i = 1; i <= x->size[1]; i++) {
    i1 = i2 + 1;
    i2 += x->size[0];
    iy++;
    exitg1 = false;
    while ((!exitg1) && (i1 <= i2)) {
      if (!x->data[i1 - 1]) {
        y->data[iy] = false;
        exitg1 = true;
      } else {
        i1++;
      }
    }
  }
}

/*
 * Arguments    : const emxArray_boolean_T *x
 * Return Type  : boolean_T
 */
boolean_T c_all(const emxArray_boolean_T *x)
{
  boolean_T y;
  int ix;
  boolean_T exitg1;
  y = true;
  ix = 1;
  exitg1 = false;
  while ((!exitg1) && (ix <= x->size[1])) {
    if (!x->data[ix - 1]) {
      y = false;
      exitg1 = true;
    } else {
      ix++;
    }
  }

  return y;
}

/*
 * Arguments    : const emxArray_boolean_T *x
 *                emxArray_boolean_T *y
 * Return Type  : void
 */
void d_all(const emxArray_boolean_T *x, emxArray_boolean_T *y)
{
  unsigned int outsize[2];
  int i2;
  int iy;
  int i;
  int i1;
  boolean_T exitg1;
  for (i2 = 0; i2 < 2; i2++) {
    outsize[i2] = (unsigned int)x->size[i2];
  }

  i2 = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = (int)outsize[1];
  emxEnsureCapacity((emxArray__common *)y, i2, (int)sizeof(boolean_T));
  iy = (int)outsize[1];
  for (i2 = 0; i2 < iy; i2++) {
    y->data[i2] = true;
  }

  i2 = 0;
  iy = -1;
  for (i = 1; i <= x->size[1]; i++) {
    i1 = i2 + 1;
    i2 += x->size[0];
    iy++;
    exitg1 = false;
    while ((!exitg1) && (i1 <= i2)) {
      if (!x->data[i1 - 1]) {
        y->data[iy] = false;
        exitg1 = true;
      } else {
        i1++;
      }
    }
  }
}

/*
 * File trailer for all.c
 *
 * [EOF]
 */
