/*
 * government, commercial, or other organizational use.
 * File: all.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

#ifndef ALL_H
#define ALL_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "pairGenVar_types.h"

/* Function Declarations */
extern boolean_T all(const emxArray_boolean_T *x);
extern void b_all(const emxArray_boolean_T *x, emxArray_boolean_T *y);
extern boolean_T c_all(const emxArray_boolean_T *x);
extern void d_all(const emxArray_boolean_T *x, emxArray_boolean_T *y);

#endif

/*
 * File trailer for all.h
 *
 * [EOF]
 */
