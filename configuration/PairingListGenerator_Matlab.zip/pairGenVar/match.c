/*
 * File: match.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "pairGenVar.h"
#include "match.h"
#include "sort1.h"

/* Function Definitions */

/*
 * Arguments    : emxArray_real_T *A
 *                emxArray_real_T *x
 * Return Type  : void
 */
void match(emxArray_real_T *A, emxArray_real_T *x)
{
  int k;
  double i;
  int i2;
  int l;
  double b_l;
  sort(x);

  /*  if length(x)~=6 */
  /*      display('Es m�ssen 6 Boote an einer Wettfahrt teilnehmen') */
  /*  end */
  for (k = 0; k < x->size[1]; k++) {
    i = x->data[k];
    i2 = (int)((double)x->size[1] + (1.0 - ((1.0 + (double)k) + 1.0)));
    for (l = 0; l < i2; l++) {
      b_l = ((1.0 + (double)k) + 1.0) + (double)l;
      A->data[((int)i + A->size[0] * ((int)x->data[(int)b_l - 1] - 1)) - 1]++;
      A->data[((int)x->data[(int)b_l - 1] + A->size[0] * ((int)i - 1)) - 1]++;
    }
  }
}

/*
 * File trailer for match.c
 *
 * [EOF]
 */
