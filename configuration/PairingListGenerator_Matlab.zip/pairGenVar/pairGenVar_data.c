/*
 * File: pairGenVar_data.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "pairGenVar.h"
#include "pairGenVar_data.h"

/* Variable Definitions */
unsigned int state[625];

/*
 * File trailer for pairGenVar_data.c
 *
 * [EOF]
 */
