/*
 * File: characterize.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "pairGenVar.h"
#include "characterize.h"
#include "pairGenVar_emxutil.h"
#include "sum.h"

/* Function Definitions */

/*
 * CHARACTERIZE Returns most important characteristics of pairing matrix A
 * Detailed explanation not required
 * Provide data for histogram
 * Arguments    : const emxArray_real_T *A
 *                double *stdDev
 *                emxArray_real_T *histo
 * Return Type  : void
 */
void characterize(const emxArray_real_T *A, double *stdDev, emxArray_real_T
                  *histo)
{
  emxArray_real_T *allValues;
  int ixstart;
  int n;
  int i;
  int ix;
  double xbar;
  int ixstop;
  boolean_T exitg1;
  boolean_T exitg2;
  int k;
  double r;
  int j;
  unsigned int l;
  double y;
  emxInit_real_T(&allValues, 2);
  ixstart = allValues->size[0] * allValues->size[1];
  allValues->size[0] = 1;
  allValues->size[1] = A->size[1];
  emxEnsureCapacity((emxArray__common *)allValues, ixstart, (int)sizeof(double));
  n = A->size[0];
  for (i = 0; i + 1 <= A->size[1]; i++) {
    ix = i * n;
    ixstart = i * n + 1;
    ixstop = ix + n;
    xbar = A->data[ix];
    if (n > 1) {
      if (rtIsNaN(A->data[ix])) {
        ix = ixstart;
        exitg2 = false;
        while ((!exitg2) && (ix + 1 <= ixstop)) {
          ixstart = ix + 1;
          if (!rtIsNaN(A->data[ix])) {
            xbar = A->data[ix];
            exitg2 = true;
          } else {
            ix++;
          }
        }
      }

      if (ixstart < ixstop) {
        while (ixstart + 1 <= ixstop) {
          if (A->data[ixstart] > xbar) {
            xbar = A->data[ixstart];
          }

          ixstart++;
        }
      }
    }

    allValues->data[i] = xbar;
  }

  ixstart = 1;
  n = allValues->size[1];
  xbar = allValues->data[0];
  if (allValues->size[1] > 1) {
    if (rtIsNaN(allValues->data[0])) {
      ix = 2;
      exitg1 = false;
      while ((!exitg1) && (ix <= n)) {
        ixstart = ix;
        if (!rtIsNaN(allValues->data[ix - 1])) {
          xbar = allValues->data[ix - 1];
          exitg1 = true;
        } else {
          ix++;
        }
      }
    }

    if (ixstart < allValues->size[1]) {
      while (ixstart + 1 <= n) {
        if (allValues->data[ixstart] > xbar) {
          xbar = allValues->data[ixstart];
        }

        ixstart++;
      }
    }
  }

  ixstart = histo->size[0] * histo->size[1];
  histo->size[0] = 1;
  histo->size[1] = (int)(xbar + 1.0);
  emxEnsureCapacity((emxArray__common *)histo, ixstart, (int)sizeof(double));
  ixstop = (int)(xbar + 1.0);
  for (ixstart = 0; ixstart < ixstop; ixstart++) {
    histo->data[ixstart] = 0.0;
  }

  for (k = 0; k < (int)(xbar + 1.0); k++) {
    if ((A->size[0] == 0) || (A->size[1] == 0)) {
      ixstart = 0;
    } else {
      ixstop = A->size[0];
      ixstart = A->size[1];
      if (ixstop >= ixstart) {
        ixstart = ixstop;
      }
    }

    for (i = 0; i < ixstart; i++) {
      if ((A->size[0] == 0) || (A->size[1] == 0)) {
        n = 0;
      } else {
        ixstop = A->size[0];
        n = A->size[1];
        if (ixstop >= n) {
          n = ixstop;
        }
      }

      for (j = 0; j < n; j++) {
        if (A->data[i + A->size[0] * j] == k) {
          histo->data[k]++;
        }
      }
    }
  }

  /* Compute standard deviation of histogram values */
  /* Create single row vector that can hold all non-diagonal pairing counts */
  ixstart = allValues->size[0] * allValues->size[1];
  allValues->size[0] = 1;
  allValues->size[1] = (int)sum(histo);
  emxEnsureCapacity((emxArray__common *)allValues, ixstart, (int)sizeof(double));
  r = sum(histo);
  ixstop = (int)r;
  for (ixstart = 0; ixstart < ixstop; ixstart++) {
    allValues->data[ixstart] = 0.0;
  }

  l = 1U;

  /* Iterate through all elements in variable 'histo' */
  for (k = 0; k < (int)(xbar + 1.0); k++) {
    /* Insert respective number of elements (which is stored in histo(k)) */
    /* of value k-1 into 'allValues' */
    for (i = 0; i < (int)histo->data[k]; i++) {
      allValues->data[(int)l - 1] = (1.0 + (double)k) - 1.0;
      l++;
    }
  }

  ixstart = allValues->size[1];
  ixstop = allValues->size[1];
  if (ixstop > 1) {
    ixstop = allValues->size[1];
    n = ixstop - 1;
  } else {
    n = allValues->size[1];
  }

  ixstop = allValues->size[1];
  if (ixstop == 0) {
    y = 0.0;
  } else {
    ix = 0;
    xbar = allValues->data[0];
    for (k = 2; k <= ixstart; k++) {
      ix++;
      xbar += allValues->data[ix];
    }

    ixstop = allValues->size[1];
    xbar /= (double)ixstop;
    ix = 0;
    r = allValues->data[0] - xbar;
    y = r * r;
    for (k = 2; k <= ixstart; k++) {
      ix++;
      r = allValues->data[ix] - xbar;
      y += r * r;
    }

    y /= (double)n;
  }

  emxFree_real_T(&allValues);
  *stdDev = sqrt(y);
}

/*
 * File trailer for characterize.c
 *
 * [EOF]
 */
