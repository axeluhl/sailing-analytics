/*
 * File: pairGenVar.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

#ifndef PAIRGENVAR_H
#define PAIRGENVAR_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "pairGenVar_types.h"

/* Function Declarations */
extern void pairGenVar(double flights, double boats, double teams, double nIter,
  emxArray_real_T *PBest, emxArray_real_T *ABest, emxArray_real_T *histBest,
  double devBest_data[], int devBest_size[2]);

#endif

/*
 * File trailer for pairGenVar.h
 *
 * [EOF]
 */
