/*
 * File: sort1.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "pairGenVar.h"
#include "sort1.h"
#include "pairGenVar_emxutil.h"
#include "sortIdx.h"

/* Function Definitions */

/*
 * Arguments    : emxArray_real_T *x
 * Return Type  : void
 */
void sort(emxArray_real_T *x)
{
  emxArray_real_T *vwork;
  int i3;
  int k;
  int i4;
  emxArray_int32_T *b_vwork;
  emxInit_real_T2(&vwork, 1);
  i3 = x->size[1];
  k = x->size[1];
  i4 = vwork->size[0];
  vwork->size[0] = k;
  emxEnsureCapacity((emxArray__common *)vwork, i4, (int)sizeof(double));
  for (k = 0; k + 1 <= i3; k++) {
    vwork->data[k] = x->data[k];
  }

  emxInit_int32_T(&b_vwork, 1);
  sortIdx(vwork, b_vwork);
  k = 0;
  emxFree_int32_T(&b_vwork);
  while (k + 1 <= i3) {
    x->data[k] = vwork->data[k];
    k++;
  }

  emxFree_real_T(&vwork);
}

/*
 * File trailer for sort1.c
 *
 * [EOF]
 */
