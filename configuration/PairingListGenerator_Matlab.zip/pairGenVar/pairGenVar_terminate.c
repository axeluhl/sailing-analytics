/*
 * File: pairGenVar_terminate.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "pairGenVar.h"
#include "pairGenVar_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void pairGenVar_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for pairGenVar_terminate.c
 *
 * [EOF]
 */
