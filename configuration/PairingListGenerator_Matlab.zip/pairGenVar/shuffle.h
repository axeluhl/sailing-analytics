/*
 * File: shuffle.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

#ifndef SHUFFLE_H
#define SHUFFLE_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "pairGenVar_types.h"

/* Function Declarations */
extern void shuffle(const emxArray_real_T *POld, emxArray_real_T *PShuffled);

#endif

/*
 * File trailer for shuffle.h
 *
 * [EOF]
 */
