/*
 * File: rand.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

#ifndef RAND_H
#define RAND_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "pairGenVar_types.h"

/* Function Declarations */
extern double b_rand(void);
extern void c_rand(double varargin_2, emxArray_real_T *r);

#endif

/*
 * File trailer for rand.h
 *
 * [EOF]
 */
