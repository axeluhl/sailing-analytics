/*
 * File: shuffle.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Jul-2016 12:33:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "pairGenVar.h"
#include "shuffle.h"
#include "pairGenVar_emxutil.h"
#include "rand.h"

/* Function Definitions */

/*
 * SHUFFLE individually permutates all m rows in a m by n matrix
 * NO further details
 * Arguments    : const emxArray_real_T *POld
 *                emxArray_real_T *PShuffled
 * Return Type  : void
 */
void shuffle(const emxArray_real_T *POld, emxArray_real_T *PShuffled)
{
  int n;
  int i;
  int k;
  int b_i;
  emxArray_real_T *randOrd;
  emxArray_int32_T *idx;
  emxArray_int32_T *iwork;
  emxArray_real_T *b_idx;
  int b_n;
  int b_randOrd[2];
  boolean_T p;
  int i2;
  int j;
  int pEnd;
  int b_p;
  int q;
  int qEnd;
  int kEnd;
  n = POld->size[1];
  i = PShuffled->size[0] * PShuffled->size[1];
  PShuffled->size[0] = POld->size[0];
  PShuffled->size[1] = POld->size[1];
  emxEnsureCapacity((emxArray__common *)PShuffled, i, (int)sizeof(double));
  k = POld->size[0] * POld->size[1];
  for (i = 0; i < k; i++) {
    PShuffled->data[i] = 0.0;
  }

  /* Perform permutation for every row 1 to m */
  b_i = 0;
  emxInit_real_T(&randOrd, 2);
  emxInit_int32_T1(&idx, 2);
  emxInit_int32_T(&iwork, 1);
  emxInit_real_T2(&b_idx, 1);
  while (b_i <= POld->size[0] - 1) {
    c_rand(n, randOrd);
    i = idx->size[0] * idx->size[1];
    idx->size[0] = 1;
    idx->size[1] = randOrd->size[1];
    emxEnsureCapacity((emxArray__common *)idx, i, (int)sizeof(int));
    k = randOrd->size[1];
    for (i = 0; i < k; i++) {
      idx->data[i] = 0;
    }

    if (randOrd->size[1] == 0) {
    } else {
      b_n = randOrd->size[1] + 1;
      k = randOrd->size[1];
      i = iwork->size[0];
      iwork->size[0] = k;
      emxEnsureCapacity((emxArray__common *)iwork, i, (int)sizeof(int));
      for (k = 1; k <= b_n - 2; k += 2) {
        if ((randOrd->data[k - 1] <= randOrd->data[k]) || rtIsNaN(randOrd->
             data[k])) {
          p = true;
        } else {
          p = false;
        }

        if (p) {
          idx->data[k - 1] = k;
          idx->data[k] = k + 1;
        } else {
          idx->data[k - 1] = k + 1;
          idx->data[k] = k;
        }
      }

      if ((randOrd->size[1] & 1) != 0) {
        idx->data[randOrd->size[1] - 1] = randOrd->size[1];
      }

      i = 2;
      while (i < b_n - 1) {
        i2 = i << 1;
        j = 1;
        for (pEnd = 1 + i; pEnd < b_n; pEnd = qEnd + i) {
          b_p = j;
          q = pEnd - 1;
          qEnd = j + i2;
          if (qEnd > b_n) {
            qEnd = b_n;
          }

          k = 0;
          kEnd = qEnd - j;
          while (k + 1 <= kEnd) {
            if ((randOrd->data[idx->data[b_p - 1] - 1] <= randOrd->data
                 [idx->data[q] - 1]) || rtIsNaN(randOrd->data[idx->data[q] - 1]))
            {
              p = true;
            } else {
              p = false;
            }

            if (p) {
              iwork->data[k] = idx->data[b_p - 1];
              b_p++;
              if (b_p == pEnd) {
                while (q + 1 < qEnd) {
                  k++;
                  iwork->data[k] = idx->data[q];
                  q++;
                }
              }
            } else {
              iwork->data[k] = idx->data[q];
              q++;
              if (q + 1 == qEnd) {
                while (b_p < pEnd) {
                  k++;
                  iwork->data[k] = idx->data[b_p - 1];
                  b_p++;
                }
              }
            }

            k++;
          }

          for (k = 0; k + 1 <= kEnd; k++) {
            idx->data[(j + k) - 1] = iwork->data[k];
          }

          j = qEnd;
        }

        i = i2;
      }
    }

    k = idx->size[1];
    i = b_idx->size[0];
    b_idx->size[0] = k;
    emxEnsureCapacity((emxArray__common *)b_idx, i, (int)sizeof(double));
    for (i = 0; i < k; i++) {
      b_idx->data[i] = idx->data[i];
    }

    for (i = 0; i < 2; i++) {
      b_randOrd[i] = randOrd->size[i];
    }

    i = randOrd->size[0] * randOrd->size[1];
    randOrd->size[0] = 1;
    randOrd->size[1] = b_randOrd[1];
    emxEnsureCapacity((emxArray__common *)randOrd, i, (int)sizeof(double));
    k = b_randOrd[1];
    for (i = 0; i < k; i++) {
      randOrd->data[randOrd->size[0] * i] = b_idx->data[b_randOrd[0] * i];
    }

    for (j = 0; j < n; j++) {
      PShuffled->data[b_i + PShuffled->size[0] * j] = POld->data[b_i +
        POld->size[0] * ((int)randOrd->data[j] - 1)];
    }

    b_i++;
  }

  emxFree_real_T(&b_idx);
  emxFree_int32_T(&iwork);
  emxFree_int32_T(&idx);
  emxFree_real_T(&randOrd);
}

/*
 * File trailer for shuffle.c
 *
 * [EOF]
 */
