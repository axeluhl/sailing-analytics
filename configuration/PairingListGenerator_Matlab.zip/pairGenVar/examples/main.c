/* This automatically generated example C main file shows how to call    */
/* entry-point functions that MATLAB Coder generated. You must customize */
/* this file for your application. Do not modify this file directly.     */
/* Instead, make a copy of this file, modify it, and integrate it into   */
/* your development environment.                                         */
/*                                                                       */
/* This file initializes entry-point function arguments to a default     */
/* size and value before calling the entry-point functions. It does      */
/* not store or use any values returned from the entry-point functions.  */
/* If necessary, it does pre-allocate memory for returned values.        */
/* You can use this file as a starting point for a main function that    */
/* you can deploy in your application.                                   */
/*                                                                       */
/* After you copy the file, and before you deploy it, you must make the  */
/* following changes:                                                    */
/* * For variable-size function arguments, change the example sizes to   */
/* the sizes that your application requires.                             */
/* * Change the example values of function arguments to the values that  */
/* your application requires.                                            */
/* * If the entry-point functions return values, store these values or   */
/* otherwise use them as required by your application.                   */
/*                                                                       */
/*************************************************************************/
/* Include Files */
#include "rt_nonfinite.h"
#include "pairGenVar.h"
#include "main.h"
#include "pairGenVar_terminate.h"
#include "pairGenVar_emxAPI.h"
#include "pairGenVar_initialize.h"

/* Function Declarations */
static double argInit_real_T(void);
static void main_pairGenVar(void);

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : double
 */
static double argInit_real_T(void)
{
  return 0.0;
}

/*
 * Arguments    : void
 * Return Type  : void
 */
static void main_pairGenVar(void)
{
  emxArray_real_T *PBest;
  emxArray_real_T *ABest;
  emxArray_real_T *histBest;
  double devBest_data[1];
  int devBest_size[2];
  emxInitArray_real_T(&PBest, 2);
  emxInitArray_real_T(&ABest, 2);
  emxInitArray_real_T(&histBest, 2);

  /* Initialize function 'pairGenVar' input arguments. */
  /* Call the entry-point 'pairGenVar'. */
  pairGenVar(argInit_real_T(), argInit_real_T(), argInit_real_T(),
             argInit_real_T(), PBest, ABest, histBest, devBest_data,
             devBest_size);
  emxDestroyArray_real_T(histBest);
  emxDestroyArray_real_T(ABest);
  emxDestroyArray_real_T(PBest);
}

/*
 * Arguments    : int argc
 *                const char * const argv[]
 * Return Type  : int
 */
int main(int argc, const char * const argv[])
{
  (void)argc;
  (void)argv;

  /* Initialize the application.
     You do not need to do this more than one time. */
  pairGenVar_initialize();

  /* Invoke the entry-point functions.
     You can call entry-point functions multiple times. */
  main_pairGenVar();

  /* Terminate the application.
     You do not need to do this more than one time. */
  pairGenVar_terminate();
  return 0;
}

/*
 * File trailer for main.c
 *
 * [EOF]
 */
