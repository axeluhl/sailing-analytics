function A=match(A,x)

x = sort(x);
% if length(x)~=6
%     display('Es m�ssen 6 Boote an einer Wettfahrt teilnehmen')
% end
t=length(x);
for k=1:t
    i=x(k);
    for l=(k+1):t
        j=x(l);
        A(i,j)=A(i,j)+1;
        A(j,i)=A(j,i)+1;
    end
end