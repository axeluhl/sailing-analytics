function [stdDev,histo] = characterize(A)
    %CHARACTERIZE Returns most important characteristics of pairing matrix A
    %Detailed explanation not required
    %Provide data for histogram
    maxValue = max(max(A));
    histo=zeros(1,maxValue+1);
    for k=0:maxValue
        for i=1:length(A)
            for j=1:length(A)
                if(A(i,j)==k)
                    histo(k+1)=histo(k+1)+1;
                end
            end
        end
    end
    %Compute standard deviation of histogram values
    %Create single row vector that can hold all non-diagonal pairing counts
    allValues=zeros(1,sum(histo));
    l=1;
    %Iterate through all elements in variable 'histo'
    for k=1:(maxValue+1)
        %Insert respective number of elements (which is stored in histo(k))
        %of value k-1 into 'allValues'
        for i=1:histo(k)
            allValues(l)=(k-1);
            l=l+1;
        end
    end
    stdDev = std(allValues(:));
end

