function [PBest,ABest,histBest,devBest] = pairGenVar(flights,boats,teams,nIter)
%Iterative determination of best pairing system for NRace races per flight
%Pre-defining frame parameters of optimization problem for NRace races per
%flight
%Sanity checks
if mod(teams,boats)~=0
    disp('Error: Teams must be an integer multiple of boats')
    PBest = [];
    ABest = [];
    histBest = [];
    devBest = [];
    return
end
%Determine number of races
NRace = teams/boats;
%Initialize void 'best'-parameters
ABest = zeros(teams);
PBest = zeros(flights*teams/boats,boats);
histBest = [];
devBest = Inf; %Start with initial stdDev that is higher than any naturally occuring value
%Specifiy number of iterations
q = nIter;

for r=1:q
    A=zeros(teams);
    P=zeros(flights*teams/boats,boats);
    for nr_flight=1:flights
        %allocating three "match-pairing" matrices
        x=zeros(NRace,boats);
        pair_stats=zeros(NRace-1,boats-1,teams);
        pair_max=zeros(NRace-1,1);
        %filling in pairings for RACE 1
        %taking a random team as initial competitor
        x(1,1)=randi(teams);
        %finding every subsequent competitor with as little races priorly sailed
        %against the already chosen competitors as possible
        for i=1:(boats-1)
            pair_min=(flights+1)*boats; %make sure pair_min is larger than pairstats for 1st iteration
            pair_max(1)=flights+1;
            pair_stats(1,i,:)= A(x(1,i),:);
            for j=1:(teams)
            if (sum(pair_stats(1,:,j)) <= pair_min) && (all(x(1,:)~=j) && max(pair_stats(1,:,j))<=pair_max(1))
                x(1,i+1)=j;
                pair_min=sum(pair_stats(1,:,j));
                pair_max(1)=max(pair_stats(1,:,j));
            end
            end
        end
    for a=2:(NRace-1)
        %filling in pairings for RACES 2-(NRace-1)
        %defining the team with the lowest number (that has not yet been
        %allocated to match 1) as the initial competitor of match 2
        for aux=1:teams
            if (all(all(x(1:(a-1),:)~=aux,1),2))
                x(a,1)=aux;
                break;
            end
        end
        %finding every subsequent competitor with as little races priorly sailed
        %against the already chosen competitors as possible
        for i=1:(boats-1)
            pair_min=(flights+1)*boats;
            pair_max(a)=flights+1;
            pair_stats(a,i,:)= A(x(a,i),:);
            for j=1:(teams)
            if ((sum(pair_stats(a,:,j)) <= pair_min) && (all(all(x(1:a,:)~=j))) && (max(pair_stats(a,:,j))<=pair_max(a)))
                x(a,i+1)=j;
                pair_min=sum(pair_stats(a,:,j));
                pair_max(a)=max(pair_stats(a,:,j));
            end
            end
        end
    end
        %filling in pairings for last RACE 
        %(teams competing in last race are all those, who do not compete in
        %any of the previous races
        for i=1:boats
            for aux=1:teams
                if (all(all(x~=aux)))
                x(NRace,i)=aux;
                break;
                end
            end
        end

        %Updating Matrices A and P
        for m=1:NRace
            A=match(A,x(m,:));
        end
        for m=1:NRace
            P((nr_flight-1)*NRace+m,:)=x(m,:);
        end

    end
    %All main diagonal elements in A are converted to NaN to facilitate statistical
    %analysis
    for d=1:teams
        A(d,d)=NaN;
    end
    [currentDev,~] = characterize(A);
    if (currentDev<devBest(1,1))
        ABest = A;
        PBest = P;
        [devBest,histBest]=characterize(A);
    end
end
PBest = shuffle(PBest);
end