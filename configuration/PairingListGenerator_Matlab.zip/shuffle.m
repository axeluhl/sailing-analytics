function [PShuffled] = shuffle(POld)
%SHUFFLE individually permutates all m rows in a m by n matrix 
%NO further details
m = size(POld,1);
n = size(POld,2);
PShuffled = zeros(m,n);
%Perform permutation for every row 1 to m
for i=1:m
    randOrd = randperm(n);
    for j=1:n
        PShuffled(i,j)=POld(i,randOrd(j));
    end
end
end

